
using System;
using System.Linq;
using System.Windows.Forms;

namespace Hospital_Patient_Records
{
    public partial class DoctorHome : Form
    {
        public DoctorHome()
        {
            InitializeComponent();
            LoadPatients();
        }

        void LoadPatients()
        {
            dgvPatients.DataSource = Database.Conn.Table<Patient>().ToList();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (dgvPatients.SelectedRows.Count == 0) return;

            var patient = dgvPatients.SelectedRows[0].DataBoundItem as Patient;

            patient.DoctorNote = txtNote.Text;
            patient.FitStatus =
                rbFit.Checked ? "Fit to Work" :
                rbNotFit.Checked ? "Not Fit to Work" :
                rbAccept.Checked ? "Accepted" : "Refused";

            Database.Conn.Update(patient);
            MessageBox.Show("Updated");
        }
    }
}
