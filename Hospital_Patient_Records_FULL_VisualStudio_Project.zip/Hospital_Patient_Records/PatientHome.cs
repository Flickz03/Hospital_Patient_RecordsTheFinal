
using System;
using System.Linq;
using System.Windows.Forms;

namespace Hospital_Patient_Records
{
    public partial class PatientHome : Form
    {
        int patientId;

        public PatientHome(int id)
        {
            InitializeComponent();
            patientId = id;
            LoadData();
        }

        void LoadData()
        {
            var p = Database.Conn.Table<Patient>().First(x => x.Id == patientId);

            lblName.Text = p.FirstName + " " + p.LastName;

            double bmi = p.Weight / Math.Pow(p.Height / 100, 2);
            lblBMI.Text = bmi.ToString("0.00");

            lblCondition.Text =
                bmi < 18.5 ? "Underweight" :
                bmi < 25 ? "Normal" :
                bmi < 30 ? "Overweight" : "Obese";

            dgvData.DataSource = new[] { p };
        }
    }
}
