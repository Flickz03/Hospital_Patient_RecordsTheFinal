
using System;
using System.Windows.Forms;

namespace Hospital_Patient_Records
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text != txtRePassword.Text)
            {
                MessageBox.Show("Passwords do not match");
                return;
            }

            Database.Conn.Insert(new Patient
            {
                Email = txtEmail.Text,
                Password = txtPassword.Text,
                FirstName = txtFirstName.Text,
                MiddleName = txtMiddleName.Text,
                LastName = txtLastName.Text,
                MedicalHistory = txtMedicalHistory.Text,
                Height = (double)numHeight.Value,
                Weight = (double)numWeight.Value,
                Birthday = dtpBirthday.Value.ToShortDateString()
            });

            MessageBox.Show("Account created successfully");
            new Form1().Show();
            this.Hide();
        }
    }
}
