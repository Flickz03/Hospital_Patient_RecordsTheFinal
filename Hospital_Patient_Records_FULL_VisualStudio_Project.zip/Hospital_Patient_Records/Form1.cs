
using System;
using System.Linq;
using System.Windows.Forms;

namespace Hospital_Patient_Records
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (cmbRole.Text == "Doctor")
            {
                if (txtEmail.Text == "RoySamanegro" && txtPassword.Text == "SBAPN")
                {
                    new DoctorHome().Show();
                    this.Hide();
                }
                else MessageBox.Show("Invalid doctor credentials");
                return;
            }

            var patient = Database.Conn.Table<Patient>()
                .FirstOrDefault(p => p.Email == txtEmail.Text && p.Password == txtPassword.Text);

            if (patient != null)
            {
                new PatientHome(patient.Id).Show();
                this.Hide();
            }
            else MessageBox.Show("Invalid patient login");
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            new Register().Show();
            this.Hide();
        }
    }
}
